#!/bin/bash

rm -rf *terraform.tfstate*
rm -rf .terraform*
rm -rf *.tfplan